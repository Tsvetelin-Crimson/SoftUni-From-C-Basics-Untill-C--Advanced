﻿using System;
using System.Collections.Generic;
using System.Text;

namespace E03Raiding.Core
{
    public interface IEngine
    {
        void Run();
    }
}
