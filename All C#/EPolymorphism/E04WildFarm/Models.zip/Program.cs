﻿using E04WildFarm.Core;
using System;

namespace E04WildFarm
{
    class Program
    {
        static void Main(string[] args)
        {
            IEngine engine = new Engine();
            engine.Run();


        }
    }
}
