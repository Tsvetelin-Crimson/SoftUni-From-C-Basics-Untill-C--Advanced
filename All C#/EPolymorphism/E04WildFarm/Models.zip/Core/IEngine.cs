﻿using System;
using System.Collections.Generic;
using System.Text;

namespace E04WildFarm.Core
{
    public interface IEngine
    {
        void Run();
    }
}
