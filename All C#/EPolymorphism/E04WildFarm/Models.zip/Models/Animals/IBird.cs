﻿using System;
using System.Collections.Generic;
using System.Text;

namespace E04WildFarm.Models.Animals
{
    public interface IBird
    {
        double WingSize { get; }
    }
}
