﻿namespace E04WildFarm.Models.Food
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
