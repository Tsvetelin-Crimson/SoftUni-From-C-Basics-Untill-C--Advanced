﻿namespace E04WildFarm.Models.Food
{
    public class Meat : Food
    {
        public Meat(int quantity) 
            : base(quantity)
        {
        }
    }
}
