﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicle.Core
{
    public interface IEngine
    {
        void Run();
    }
}
