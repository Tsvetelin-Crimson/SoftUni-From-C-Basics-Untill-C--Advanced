﻿using System;
using System.Collections.Generic;
using System.Text;

namespace E07Tuple
{
    class MyTuple<T, V>
    {
        public T FirstItem { get; private set; }

        public V SecondItem { get; private set; }

        public MyTuple(T firstItem, V secondItem)
        {
            this.FirstItem = firstItem;
            this.SecondItem = secondItem;
        }

        public override string ToString()
        {
            return $"{FirstItem} -> {SecondItem}";
        }
    }
}
