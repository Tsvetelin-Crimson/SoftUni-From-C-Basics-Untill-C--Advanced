﻿using System;
using System.Collections.Generic;
using System.Text;

namespace E03Telephony
{
    public interface IBrowsable
    {
        void Browse(string site);
    }
}
