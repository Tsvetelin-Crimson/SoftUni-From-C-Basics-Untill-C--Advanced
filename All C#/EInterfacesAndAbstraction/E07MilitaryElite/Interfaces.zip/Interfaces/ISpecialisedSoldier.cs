﻿using E07MilitaryElite.Enums;

namespace E07MilitaryElite.Interfaces
{
    public interface ISpecialisedSoldier : IPrivate
    {
        Corps Corps { get; }
    }
}
