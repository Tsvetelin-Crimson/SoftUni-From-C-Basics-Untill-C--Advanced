﻿namespace E07MilitaryElite.Interfaces
{
    interface ISpy : ISoldier
    {
        int CodeNumer { get; }
    }
}
