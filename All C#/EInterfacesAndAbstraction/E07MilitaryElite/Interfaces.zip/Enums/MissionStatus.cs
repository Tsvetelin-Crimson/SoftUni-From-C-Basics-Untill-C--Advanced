﻿namespace E07MilitaryElite.Enums
{
    public enum MissionStatus
    {
        invalid = 0,
        inProgress = 1,
        Finished = 2,
    }
}
