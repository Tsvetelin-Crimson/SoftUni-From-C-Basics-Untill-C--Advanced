﻿namespace E07MilitaryElite.Enums
{
    public enum Corps
    {
        neither = 0,
        Airforces = 1,
        Marines = 2,
    }
}
