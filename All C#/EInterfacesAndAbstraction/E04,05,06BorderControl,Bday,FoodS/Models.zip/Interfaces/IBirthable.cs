﻿namespace E04_05_06BorderControl_Bday_FoodS.Interfaces
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
