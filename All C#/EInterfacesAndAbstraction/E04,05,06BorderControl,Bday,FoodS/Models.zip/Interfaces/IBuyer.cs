﻿namespace E04_05_06BorderControl_Bday_FoodS.Interfaces
{
    public interface IBuyer
    {
        void BuyFood();

        int Food { get; }
    }
}
