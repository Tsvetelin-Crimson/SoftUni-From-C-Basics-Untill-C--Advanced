﻿namespace E04_05_06BorderControl_Bday_FoodS
{
    public interface IIdentifiable
    {
        string ID { get; }
    }
}
